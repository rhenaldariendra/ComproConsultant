<?php
    return [
        "home" => "Beranda",
        "service" => "Pelayanan",
        "aboutus" => "Tentang Kami",
        "contactus" => "Hubungi Kami",
    ];
?>
