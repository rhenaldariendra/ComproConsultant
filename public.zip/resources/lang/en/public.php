<?php
    return [
        "home" => "Home",
        "service" => "Service",
        "aboutus" => "About Us",
        "contactus" => "Contact Us",
    ];
?>
