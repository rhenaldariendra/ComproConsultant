<?php $__env->startSection('title', 'About Us'); ?>
<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="/assets/css/main/aboutus.css">




<img class="img_ab1" src="/assets/image/ab1.svg" alt="">

<div class="lineab"></div>

<div class="ab2">
    <h1><?php echo app('translator')->get('about.profile.title'); ?></h1>
    <p class="desc_ab2"><?php echo app('translator')->get('about.profile.description'); ?></p>
</div>

<div class="lineab"></div>

<div class="ab3">
    <div class="vision">
        <h2><?php echo app('translator')->get('about.vison.title'); ?></h2>
        <p><?php echo app('translator')->get('about.vison.description'); ?></p>
    </div>
    <div class="vision">
        <h2><?php echo app('translator')->get('about.mission.title'); ?></h2>
        <ol>
            <li><?php echo app('translator')->get('about.mission.description.first'); ?></li>
            <li><?php echo app('translator')->get('about.mission.description.second'); ?></li>
            <li><?php echo app('translator')->get('about.mission.description.third'); ?></li>
        </ol>
    </div>
</div>

<div class="lineab"></div>

<div class="ab4">
    <div class="maps">
        <div class="mapouter">
            <div class="gmap_canvas"><iframe class="gmap_iframe" width="100%" frameborder="0" scrolling="no"
                    marginheight="0" marginwidth="0"
                    src="https://maps.google.com/maps?width=600&amp;height=472&amp;hl=en&amp;q=+(ruko%20food%20plaza)&amp;t=&amp;z=16&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe><a
                    href="https://capcuttemplate.org/">Capcut Templates</a></div>
            <style>
                .mapouter {
                    /* position: relative; */
                    text-align: right;
                    width: 100%;
                    height: 550px;
                    border-radius: 10px;
                }

                .gmap_canvas {
                    border-radius: 10px;
                    overflow: hidden;
                    background: none !important;
                    width: 100%;
                    height: 550px;
                }

                .gmap_iframe {
                    height: 550px !important;
                }

            </style>
        </div>
    </div>
    <div class="findus">
        <h1><?php echo app('translator')->get('about.findus.title'); ?></h1>
        <div class="abs-address">
            <p><?php echo app('translator')->get('about.findus.address.first'); ?></p>
            <p><?php echo app('translator')->get('about.findus.address.second'); ?></p>
            <p><?php echo app('translator')->get('about.findus.address.third'); ?></p>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\myrhe\OneDrive\Documents\PH\ComproConsultant\resources\views//main/aboutus.blade.php ENDPATH**/ ?>